#include <iostream>
#include "Heap.h";

using namespace std;

int vetor[111];

int main() {
	//for (int i = 7; i >= 0; i--) {
		//vetor[7 - i] = i;
	//}

	vetor[0] = 3;
	vetor[1] = 10;
	vetor[2] = 0;
	vetor[3] = 1;
	vetor[4] = 15;
	vetor[5] = 4;
	vetor[6] = 11;
	vetor[7] = 19;

	Heap* h = new Heap(8, vetor);

	//h->imprimir();

	//h->MaxHeapify(0);
	//h->imprimir();

	//h->BuildMinHeap();
	h->HeapSort();
	h->imprimir();
}