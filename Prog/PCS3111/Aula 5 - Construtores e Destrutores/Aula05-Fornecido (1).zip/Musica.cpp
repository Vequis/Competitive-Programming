#include <iostream>

#include "Musica.h"

// IMPLEMENTAR CONSTRUTOR

string Musica::getNome() {
    return nome;
}

int Musica::getDuracao() {
    return duracao;
}

void Musica::imprimir() {
    cout << "Musica " << getNome() << " com duracao " << getDuracao() << endl;
}
