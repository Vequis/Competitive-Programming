#include <iostream>
#include "Musica.h"
#include <string>

using namespace std;

void teste() {
    Musica *m1 = new Musica(180, "Roses");

    m1->imprimir();
}

/*
int main() {
    teste();
    return 0;
}
*/
