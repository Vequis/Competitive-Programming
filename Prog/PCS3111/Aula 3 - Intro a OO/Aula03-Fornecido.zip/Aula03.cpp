#include <iostream>

// Faca os includes necessarios

using namespace std;

class Musica {
public:
    string nome;
    int duracao;
    int quantidadeDeAvaliacoes = 0;
    int somaDasAvaliacoes = 0;

    void avaliar(int valor);
    double getMedia();

    void imprimir();
};

/** Implementar metodos da classe Musica **/

class Playlist {
public:
    string nome;
    Musica* m1 = NULL;
    Musica* m2 = NULL;

    int getDuracao();
    bool adicionar(Musica* m);
};

/** Implementar metodos da classe Playlist **/


/** Implementar a funcao teste **/
void teste() {
    // IMPLEMENTE seguindo o enunciado
}


/** COMENTE a funcao main() ANTES DE ENVIAR AO JUDGE! **/
int main() {
    teste();
    return 0;
}
