#include <iostream>
#include "PersistenciaMusica.h"

using namespace std;



void teste() {
    PersistenciaMusica* p = new PersistenciaMusica("teste.txt");

    Musica* m1 = new Musica(5, "Valerie", 100, 450);
    Musica* m2 = new Musica(4, "Layla", 200, 990);

    p->inserir(m1);
    p->inserir(m2);
}

/*
int main() {
    teste();
    return 0;
}
*/
