#include <stdexcept>
#include <fstream>

#include "PersistenciaMusica.h"

using namespace std;

PersistenciaMusica::PersistenciaMusica(string arquivo) {
    this->arquivo = arquivo;
}

PersistenciaMusica::~PersistenciaMusica() {
    
}

void PersistenciaMusica::inserir(Musica* m) {
    ofstream output;

    output.open(arquivo, ios_base::app);

    output << m->getNome() << endl
        << m->getDuracao() << endl
        << m->getQuantidadeAvaliacoes() << endl
        << m->getSomaDasAvaliacoes() << endl;

    output.close();
}
