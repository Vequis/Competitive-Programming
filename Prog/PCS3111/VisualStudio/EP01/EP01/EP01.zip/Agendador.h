#ifndef AGENDADOR_H
#define AGENDADOR_H

#include "Evento.h"
#include "Roteador.h"
#include "Rede.h"

class Agendador{
private:
    int instanteAtual;
    Rede *rede;
    int tamanhoMaximo;
    int quantidade; // de eventos alocados
    Evento **eventos; //PriorityQueue 0-indexado : Estrutura Heap
public:
    Agendador(int instanteInicial, Rede* rede, int tamanho);
    ~Agendador();

    bool agendar(int instante, Roteador* r, Datagrama* d);
    void processar();
    int getInstante();
    int getQuantidade();

    //Funcoes do Heap
    int Pai(int i);
    int FilhoDireito(int i);
    int FilhoEsquerdo(int i);
    void MinHeapify(int i); //O topo da pilha sempre ter� o menor instante
    void InserirHeap(Evento *e);
    void RemoveTopoHeap();
};

#endif
