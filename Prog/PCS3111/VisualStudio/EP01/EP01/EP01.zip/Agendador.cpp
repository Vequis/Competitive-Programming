#include "Agendador.h"
#include <iostream>

using namespace std;

Agendador::Agendador(int instanteInicial, Rede* rede, int tamanho) :
instanteAtual(instanteInicial), rede(rede), tamanhoMaximo(tamanho) {
    eventos = new Evento*[tamanho];
    quantidade = 0;
}

Agendador::~Agendador() {
    for(int i = 0; i < quantidade; i++) {
        delete eventos[i];
    }

    delete[] eventos;
}

bool Agendador::agendar(int instante, Roteador* r, Datagrama* d) {
    if (quantidade == tamanhoMaximo) return false;

    Evento *atual = new Evento(instante, r, d);
    
    InserirHeap(atual);
}

void Agendador::processar() {

    //Enquanto o instante do topo <= instanteAtual
    while (quantidade > 0 && eventos[0]->getInstante() <= instanteAtual) {
        Roteador* rot_atual = eventos[0]->getDestino();
        Datagrama* d_atual = eventos[0]->getDatagrama();
        rot_atual->receber(d_atual);

        this->RemoveTopoHeap();
    }

    Roteador **roteadores = rede->getRoteadores();
    int quantidadeRede = rede->getQuantidade();

    for (int i = 0; i < quantidadeRede; i++) {
        Evento *atual = roteadores[i]->processar(instanteAtual);
        //Se o roteador analisado n�o possuir nenhum evento
        // a ser processado, ent�o atual = NULL;
        if (atual != NULL) {
            this->agendar(atual->getInstante(), atual->getDestino(), atual->getDatagrama());
        }
    }

    instanteAtual++;
}

int Agendador::getInstante() {
    return this->instanteAtual;
}

int Agendador::getQuantidade() {
    return this->quantidade;
}

//Funcoes Heap

int Agendador::Pai(int i) {
    return (i - 1) / 2;
}

int Agendador::FilhoEsquerdo(int i) {
    return 2 * i + 1;
}

int Agendador::FilhoDireito(int i) {
    return 2 * i + 2;
}

void Agendador::MinHeapify(int i) {
    int l = FilhoEsquerdo(i);
    int r = FilhoDireito(i);

    int menor = i;

    if (l < quantidade && eventos[l]->getInstante() < eventos[menor]->getInstante()) {
        menor = l;
    }

    if (r < quantidade && eventos[r]->getInstante() < eventos[menor]->getInstante()) {
        menor = r;
    }

    if (menor != i) {
        Evento* temp = eventos[i];
        eventos[i] = eventos[menor];
        eventos[menor] = temp;
        this->MinHeapify(menor);
    }
}

void Agendador::InserirHeap(Evento* e) {
    int i = quantidade; //indice atual do evento e
    
    eventos[i] = e;

    while (i>0 && e->getInstante() < eventos[Pai(i)]->getInstante()) {
        eventos[i] = eventos[Pai(i)];
        eventos[Pai(i)] = e;

        i = Pai(i);
    }

    quantidade++;
}

void Agendador::RemoveTopoHeap() {
    delete eventos[0];

    quantidade--;
    eventos[0] = eventos[quantidade];
    MinHeapify(0);
}
