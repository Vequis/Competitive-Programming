//FACA OS INCLUDES NECESARIOS

//IMPLEMENTE AS FUNCOES
// EXERCICIO 1
int calcularNota(int numeroDeReproducoes, int quantidadeDePositivos, int quantidadeDeUsuariosQueOuviram) {
}

// EXERCICIO 2
/*
int calcularTempoTotal(int nota, int notas[], int duracoes[], int quantidade) {
}
*/

// EXERCICIO 3
/*
bool temRepetido(string artistas[], int quantidade) {
}
*/

/* COMENTE A MAIN PARA SUBMETER */
int main() {

    return 0;
}
