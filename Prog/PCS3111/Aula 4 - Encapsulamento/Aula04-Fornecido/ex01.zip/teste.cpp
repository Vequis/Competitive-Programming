#include <iostream>
#include "Musica.h"
#include <string>
using namespace std;

void teste() {
    Musica *m1 = new Musica;

    m1->setNome("Roses");
    m1->setDuracao(180);

    m1->avaliar(3);
    m1->avaliar(3);
    m1->avaliar(1);

    m1->imprimir();
}

/*
int main() {
    teste();
    return 0;
}
*/

