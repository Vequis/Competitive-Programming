// Use os includes necessarios.
// Exercicio 1
string* encontrarMusica(int duracoes[], string estilos[], string nomes[],
                        int quantidade, string estilo, int duracao) {
    // Implemente a funcao
}

// Exercicio 2
int calcularEstatisticas(int duracoes[], int quantidade, int& minimo,
                         int* maximo) {
    // Implemente a funcao
}


////////////////////////////////////////////
// REMOVA A MAIN ANTES DE ENVIAR AO JUDGE //
////////////////////////////////////////////
int main() {
    // Teste a funcao
}
