#include <iostream>
#include "Pessoa.h"
#include "Banda.h"

using namespace std;

void teste() {
    Banda* b = new Banda(3, "Banda do Mar");

    b->adicionar(new Pessoa(3, "Marcelo Camelo"));
    b->adicionar(new Pessoa(3, "Maria Luiza"));

    b->imprimir();
}

/*
int main() {
    teste();
    return 0;
}
*/
