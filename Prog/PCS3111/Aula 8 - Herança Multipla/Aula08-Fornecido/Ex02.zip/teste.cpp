#include <iostream>
#include "UsuarioPessoa.h"

using namespace std;

void teste() {
    UsuarioPessoa* up = new UsuarioPessoa("Tom Jobim", "tom@usp.br", 1, 1);

    up->imprimir();
}

/*
int main() {
    teste();
    return 0;
}
*/

