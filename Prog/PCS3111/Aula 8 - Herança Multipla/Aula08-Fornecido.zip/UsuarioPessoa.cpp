/* Implemente a classe aqui */
