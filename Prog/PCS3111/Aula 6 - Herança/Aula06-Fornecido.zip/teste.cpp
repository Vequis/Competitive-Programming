// Faca os includes necessarios

void teste() {
    // IMPLEMENTE seguindo o enunciado
}

int main() {
    teste();
    return 0;
}
