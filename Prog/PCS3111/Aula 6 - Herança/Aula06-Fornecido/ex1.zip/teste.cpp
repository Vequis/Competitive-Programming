#include<string>
#include<iostream>
#include "Banda.h"

void teste() {
    Artista *a = new Banda(20, 5, "Snarky Puppy");

    a->adicionarMusica(new Musica(645, "Lingus"));
    a->adicionarMusica(new Musica(343, "Tio Macaco"));

    Banda *b = static_cast<Banda*>(a);

    b->imprimir();

    delete b;
}

/*
int main() {
    teste();
    return 0;
}
*/
