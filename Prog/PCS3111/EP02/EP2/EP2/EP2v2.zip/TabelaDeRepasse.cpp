#include "TabelaDeRepasse.h"
#include <iostream>
#include <stdexcept>

using namespace std;

TabelaDeRepasse::TabelaDeRepasse(int tamanho) : tamanho(tamanho){
    if (tamanho <= 0) {
        throw new invalid_argument("Tamanho invalido");
    }
    
    destinos = new int[tamanho];
    adjacentes = new No*[tamanho];
    atrasos = new int[tamanho];

    qtd_adjacentes = 0;
    padrao = NULL;
    atraso_padrao = 0;
}

TabelaDeRepasse::~TabelaDeRepasse(){
    delete[] destinos;
    delete[] adjacentes;
    delete[] atrasos;
}

void TabelaDeRepasse::mapear(int endereco, No* adjacente, int atraso){
    if (qtd_adjacentes == tamanho) {
        throw new overflow_error("Tabela de Repasse cheia");
    }

    for (int i = 0; i < qtd_adjacentes; i++) {
        if (destinos[i] == endereco) {
            throw new invalid_argument("Endereco repetido");
        }
    }
    // A função sairá deste for se, e somente se, o endereco não estiver na tabela

    destinos[qtd_adjacentes] = endereco;
    adjacentes[qtd_adjacentes] = adjacente;
    atrasos[qtd_adjacentes] = atraso;
    qtd_adjacentes++;
}

No** TabelaDeRepasse::getAdjacentes() {
    return adjacentes;
}

int TabelaDeRepasse::getQuantidadeDeAdjacentes() {
    return qtd_adjacentes;
}

void TabelaDeRepasse::setPadrao(No* padrao, int atraso) {
    this->padrao = padrao;
    this->atraso_padrao = atraso;
}

No* TabelaDeRepasse::getProximoSalto(int endereco, int& atraso){
    for (int i = 0; i < qtd_adjacentes; i++){
        if (destinos[i] == endereco){
            atraso = atrasos[i];
            return adjacentes[i];
        }
    }
    //Sairá deste for se, e somente se, não tiver encontrado o endereco especificado

    atraso = atraso_padrao;
    return padrao;
}

void TabelaDeRepasse::imprimir() {
    cout << "Essa tabela mapeia " << this->getQuantidadeDeAdjacentes() << " nos adjacentes" << endl;
}

