#include "FilaComPrioridade.h"
#include <stdexcept>

FilaComPrioridade::FilaComPrioridade(int tamanho) : Fila(tamanho) {
	fila = new Fila(10);
	ultimoPrioritario = nullptr;
	qntd_prioritarios = 0;
}

FilaComPrioridade::~FilaComPrioridade() {
	delete fila;
}

void FilaComPrioridade::enqueue(Datagrama* d, bool prioritario) {
	if (qtde_alocados == tamanho) {
		throw new overflow_error("Fila prioritaria cheia");
	}

	if (prioritario) {
		if (fila->isEmpty()) {
			Elemento* atual = new Elemento(d);
			
			inicio = atual;

			ultimoPrioritario = atual;
		}
		else if (ultimoPrioritario == nullptr) {
			Elemento* atual = new Elemento(d);
			Elemento* temp = inicio;

			atual->setProx(temp);
			inicio = atual;

			ultimoPrioritario = atual;
		}
		else {
			Elemento* atual = new Elemento(d);
			Elemento* temp = ultimoPrioritario->getProx();

			ultimoPrioritario->setProx(atual);
			atual->setProx(temp);

			ultimoPrioritario = atual;
		}

		qntd_prioritarios++;
		qtde_alocados++;
	} else {
		fila->enqueue(d);
	}
}

void FilaComPrioridade::enqueue(Datagrama* d) {
	enqueue(d, 0);
}

Datagrama* FilaComPrioridade::dequeue() {
	
	if (qtde_alocados == 0)
		throw new underflow_error("Fila com Prioridade vazia");

	fila->dequeue();

}
