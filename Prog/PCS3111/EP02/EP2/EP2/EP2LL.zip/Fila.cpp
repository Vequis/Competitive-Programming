#include "Fila.h"
#include <iostream>
#include <stdexcept>

using namespace std;

Fila::Fila(int tamanho) : tamanho(tamanho) {
    if (tamanho <= 0)
        throw new invalid_argument("Tamanho invalido");

    inicio = nullptr;
    qtde_alocados = 0;
}

Fila::~Fila(){
    Elemento* atual = inicio;

    while (atual != nullptr) {
        Elemento* temp = atual->getProx();
        delete atual;
        atual = temp;
    }
}

void Fila::enqueue(Datagrama* d){
    if (qtde_alocados == tamanho) {
        throw new overflow_error("Fila cheia");
    } 

    Elemento* atual = inicio;

    if (inicio == nullptr) {
        inicio = new Elemento(d);
    }
    else {
        while (atual->getProx() != nullptr) {
            atual = atual->getProx();
        }

        atual->setProx(new Elemento(d));
    }
    qtde_alocados++;
}

Datagrama* Fila::dequeue(){
    if (this->isEmpty()){
        throw new underflow_error("Fila vazia");
    } else {
        Datagrama *retorno = inicio->getDado();

        Elemento* temp = inicio;

        inicio = inicio->getProx();
        qtde_alocados--;

	    return retorno;
    }
}

bool Fila::isEmpty(){
    return (qtde_alocados == 0);
}

int Fila::getSize(){
    return this->qtde_alocados;
}

void Fila::imprimir(){
    cout << "Imprimindo Fila" << endl;
    
    for (Elemento* e = inicio; e != nullptr; e = e->getProx()) {        
       e->getDado()->imprimir();
    }
}
