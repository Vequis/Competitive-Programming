#include "Elemento.h"

Elemento::Elemento(Datagrama* d) : dado(d) {
	ant = nullptr;
	prox = nullptr;
}

Elemento::~Elemento() {
}

Datagrama* Elemento::getDado() {
	return this->dado;
}

Elemento* Elemento::getProx() {
	return this->prox;
}

void Elemento::setProx(Elemento* e) {
	prox = e;
}

Elemento* Elemento::getAnt() {
	return this->ant;
}

void Elemento::setAnt(Elemento* e) {
	ant = e;
}
