#ifndef EVENTO_H
#define EVENTO_H

#include "No.h"
#include "Datagrama.h"

class No;

class Evento{
private:
    int instante;
    No *destino;
    Datagrama *d;
public:
    Evento(int instante, No* destino, Datagrama* d);
    ~Evento();

    int getInstante();
    No* getDestino();
    Datagrama* getDatagrama();

    void imprimir();
};

#endif
