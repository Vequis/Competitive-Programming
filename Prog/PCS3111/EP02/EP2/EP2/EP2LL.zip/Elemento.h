#ifndef ELEMENTO_H
#define ELEMENTO_H

#include "Datagrama.h"

class Elemento {
private:
	Datagrama* dado;
	Elemento* prox;
	Elemento* ant;
public:
	Elemento(Datagrama* d);
	~Elemento();

	Datagrama* getDado();

	Elemento* getProx();
	void setProx(Elemento* e);
	Elemento* getAnt();
	void setAnt(Elemento* e);
};

#endif