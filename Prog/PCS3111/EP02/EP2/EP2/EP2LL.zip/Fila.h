#ifndef FILA_H
#define FILA_H

#include "Elemento.h"

class Fila {
protected:
    int qtde_alocados;
    int tamanho;

    Elemento* inicio;
public:
    Fila(int tamanho);
    virtual ~Fila();

    virtual void enqueue(Datagrama* d); //Insere o datagrama na ultima posição
    virtual Datagrama* dequeue(); //Retira o elemento da frente
    virtual bool isEmpty();
    virtual int getSize();

    virtual void imprimir();
};

#endif
