#include "RoteadorComQoS.h"
#include <stdexcept>
#include <iostream>

using namespace std;

RoteadorComQoS::RoteadorComQoS(int endereco) :
	Roteador(endereco, new FilaComPrioridade(TAMANHO_FILA)) {
	destinos_priorizados = new vector<int>();
}

RoteadorComQoS::~RoteadorComQoS() {
	delete destinos_priorizados;
}

void RoteadorComQoS::priorizar(int destino) {
	destinos_priorizados->push_back(destino);
}

vector<int>* RoteadorComQoS::getDestinosPriorizados() {
	return destinos_priorizados;
}

void RoteadorComQoS::receber(Datagrama* d) {
	try {
		bool priorizado = false;
		for (int i = 0; i < (int)destinos_priorizados->size(); i++) {
			if (destinos_priorizados->at(i) == d->getDestino()) {
				priorizado = true;
			}
		}

		FilaComPrioridade* fcp = dynamic_cast<FilaComPrioridade*>(fila);

		fcp->enqueue(d, priorizado);
	} catch (overflow_error* oe) {
		delete d;
		cout << "\tFila em " << getEndereco() << " estourou" << endl;
		delete oe;
	}
}
