#include "FilaComPrioridade.h"
#include <stdexcept>

FilaComPrioridade::FilaComPrioridade(int tamanho) : Fila(tamanho) {
	prioritarios = new Fila(10);
	nao_prioritarios = new Fila(10);
	qntd_prioritarios = 0;
}

FilaComPrioridade::~FilaComPrioridade() {
	delete prioritarios;
	delete nao_prioritarios;
}

void FilaComPrioridade::enqueue(Datagrama* d, bool prioritario) {
	if (qtde_alocados == tamanho) {
		throw new overflow_error("Fila prioritaria cheia");
	}

	qtde_alocados++;

	if (prioritario) {
		prioritarios->enqueue(d);
	} else {
		nao_prioritarios->enqueue(d);
	}
}

void FilaComPrioridade::enqueue(Datagrama* d) {
	enqueue(d, 0);
}

Datagrama* FilaComPrioridade::dequeue() {
	
	if (qtde_alocados == 0)
		throw new underflow_error("Fila com Prioridade vazia");

	qtde_alocados--;

	if (!prioritarios->isEmpty()) {
		return prioritarios->dequeue();
	} 

	return nao_prioritarios->dequeue();

}
