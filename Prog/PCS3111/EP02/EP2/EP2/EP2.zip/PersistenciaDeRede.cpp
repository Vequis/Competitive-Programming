#include "PersistenciaDeRede.h"
#include <fstream>
#include <iostream>

using namespace std;

PersistenciaDeRede::PersistenciaDeRede(string arquivo) {
	this->arquivo = arquivo;
}

PersistenciaDeRede::~PersistenciaDeRede() {
}

Rede* PersistenciaDeRede::carregar() {
	ifstream input;
	input.open(arquivo);

	if (input.fail()) {
		throw new logic_error("Arquivo inexistente");
	}

	Rede* rede = new Rede();

	int qtde_roteadores;
	input >> qtde_roteadores;

	for (int i = 0; i < qtde_roteadores; ++i) {
		char c;
		input >> c;

		int endereco;
		input >> endereco;
		
		if (c == 'r') {
			rede->adicionar(new Roteador(endereco));
		} else {
			RoteadorComQoS* rqos = new RoteadorComQoS(endereco);
			int qtde_priorizados;

			input >> qtde_priorizados;

			for (int j = 0; j < qtde_priorizados; j++) {
				int endereco_priorizado;
				input >> endereco_priorizado;

				rqos->priorizar(endereco_priorizado);
			}

			rede->adicionar(rqos);
		} 
	}

	int qtde_hospedeiros;
	input >> qtde_hospedeiros;

	//<endere�o> <gateway> <atraso> <quantidade de chats> <chat1> <chat2> ...
	for (int i = 0; i < qtde_hospedeiros; ++i) {
		int endereco;
		int gateway;
		int atraso;
		int qtde_chats;

		input >> endereco >> gateway >> atraso >> qtde_chats;

		Roteador* gateway_padrao = dynamic_cast<Roteador*>(rede->getNo(gateway));

		Hospedeiro* h = new Hospedeiro(endereco, gateway_padrao, atraso);

		for (int j = 0; j < qtde_chats; ++j) {
			//<porta> <endere�o de destino> <porta de destino>
			int porta, endDestino, portaDestino;
			input >> porta >> endDestino >> portaDestino;

			h->adicionarChat(porta, endDestino, portaDestino);
		}

		rede->adicionar(h);
	}

	for (int i = 0; i < qtde_roteadores; ++i) {
		int roteador, padrao, at_padrao, qtde_mapeamentos;

		input >> roteador >> padrao >> at_padrao >> qtde_mapeamentos;

		Roteador* r = dynamic_cast<Roteador*>(rede->getNo(roteador));

		r->setPadrao(rede->getNo(padrao), at_padrao);

		for (int j = 0; j < qtde_mapeamentos; ++j) {
			int end_destino, end_adjacente, atraso;
			input >> end_destino >> end_adjacente >> atraso;

			r->mapear(end_destino, rede->getNo(end_adjacente), atraso);
		}
	}

	if (input.fail()) {
		throw new logic_error("Falha na leitura");
	}

	return rede;

	input.close();
}