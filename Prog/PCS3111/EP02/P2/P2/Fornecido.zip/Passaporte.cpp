#include "Passaporte.h"
#include <stdexcept>
#include <iostream>

using namespace std;
// Implementar

Passaporte::Passaporte(string nome)
{

}

Passaporte::~Passaporte()
{

}

string Passaporte::getNome()
{

}

bool Passaporte::aplicaVacina(Vacina* v, int dataAplicacao)
{

}

Vacina** Passaporte::getVacinas()
{

}

int* Passaporte::getDataAplicacoes()
{

}

int Passaporte::getQuantidadeVacinas()
{

}

void Passaporte::imprimir()
{

}

