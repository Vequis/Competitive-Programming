#include "Vacina.h"
#include <stdexcept>
#include <iostream>

using namespace std;
// Implementar

Vacina::Vacina(int dataFabricacao)
{

}

Vacina::~Vacina()
{

}

int Vacina::getLote()
{
}

int Vacina::getDataFabricacao()
{
}

void Vacina::imprimir(){
    // descomente apos fazer os includes necessarios
    /*
    cout    << "Lote: " << getLote()
            << ", Fabricacao: " << getDataFabricacao();
    */
}

int Vacina::getValidade(){
}
