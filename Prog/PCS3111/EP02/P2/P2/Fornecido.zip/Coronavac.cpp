#include "Coronavac.h"
#include <stdexcept>
#include <iostream>

using namespace std;

// Inicialize os contadores de doses e de lotes desta vacina

// Implementar

Coronavac::Coronavac(int dataFabricacao)
{

}

Coronavac::~Coronavac()
{

}

int Coronavac::getDataProximaDose(int dataAplicacao)
{

}

void Coronavac::imprimir()
{
    // Descomente e complete
    // cout << "Coronavac, ";
    // Utilize refinamento para invocar o m�todo imprimir de Vacina
}
