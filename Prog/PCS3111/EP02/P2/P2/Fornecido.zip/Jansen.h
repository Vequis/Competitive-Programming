#ifndef JANSEN_H
#define JANSEN_H

class Jansen {
public:
    Jansen(int dataFabricacao);
    virtual ~Jansen();
    virtual void imprimir();
private:
    // Defina as constantes estaticas

    // Defina o contador de doses da vacina

    // Defina o contador de lotes da vacina

};

#endif // JANSEN_H
