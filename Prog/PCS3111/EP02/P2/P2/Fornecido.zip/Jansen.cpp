#include "Jansen.h"
#include <stdexcept>
#include <iostream>

using namespace std;
// Inicialize os contadores de doses e de lotes desta vacina


// Implementar

Jansen::Jansen(int dataFabricacao)
{

}

Jansen::~Jansen()
{

}

void Jansen::imprimir()
{
    // Descomente e complete
    // cout << "Jansen, ";
    // Utilize refinamento para invocar o m�todo imprimir de Vacina
}
