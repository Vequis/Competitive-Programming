#ifndef CORONAVAC_H
#define CORONAVAC_H

class Coronavac {
public:
    Coronavac(int dataFabricacao);
    virtual ~Coronavac();
    static int getDataProximaDose (int dataAplicacao);
    virtual void imprimir();
private:
    // Defina as constantes estaticas
    
    // Defina o contador de doses da vacina

    // Defina o contador de lotes da vacina
};

#endif // CORONAVAC_H
