#include <iostream>
using namespace std;

#include "Vacina.h"
#include "Coronavac.h"
#include "Jansen.h"
#include "Passaporte.h"
#include "Cadastro.h"

void testeP2() {
    /*
    // Crie, nesta ordem as seguintes vacinas:
    // 2 vacinas da Coronavac no dia 20, e mais uma no dia 200
    // 1 vacinas da Jansen no dia 30, e mais uma no dia 300
    
    Vacina* vacinas[5];
    vacinas[0] = new Coronavac(20);
    vacinas[1] = new Coronavac(20);
    vacinas[2] = new Coronavac(200);
    vacinas[3] = new Jansen(30);
    vacinas[4] = new Jansen(300);

    cout << "Criando vacinas" << endl;

    cout << endl;
    for (int i = 0; i < 5; i++) {
        vacinas[i]->imprimir();
        cout << endl;
    }
    cout << endl;
    

    // Crie 2 passaportes: Judite e Ariel
    Passaporte* p1 = new Passaporte("Judite");
    Passaporte* p2 = new Passaporte("Ariel");

    cout << "Criando passaportes" << endl;


    // Crie um cadastro de nome "Posto USP" e adicione a ele os 2 passaportes

    // Dica: Cadastro *c  .... COMPLETE
    
    Cadastro* c = new Cadastro("Posto USP");
    c->adicionarPassaporte(p1);
    c->adicionarPassaporte(p2);

    cout << "Criando cadastro e adicionando passaportes" << endl;

    // Aplique as vacinas corretamente no modo abaixo:

    // Judite: Coronavac, fabricada no dia 20, 1a. dose no dia 10.
    // Ariel:  Jansen, fabricada no dia 30, no dia 40.
    
    p1->aplicaVacina(vacinas[0], 10);
    p2->aplicaVacina(vacinas[3], 40);

    cout << endl;
    p1->imprimir();
    cout << endl;
    p2->imprimir();
    cout << endl;

    cout << "Aplicando vacinas" << endl;

    // Imprima o cadastro

    // Tente aplicar a segunda dose de Coronavac (produzida no dia 20) em Judite no dia 350
    // Imprima em uma linha separada a mensagem referente ao tratamento da excecao

    // Aplique em Judite no dia 350 a dose de Coronavac produzida no dia 200

    // Tente agora aplicar em Ariel no dia 400 uma segunda dose de Jansen produzida no dia 300
    // Imprima em uma linha separada a mensagem referente ao tratamento da excecao

    // Imprima o cadastro

    c->imprimir();

    // Destrua o cadastro
    */
  }
