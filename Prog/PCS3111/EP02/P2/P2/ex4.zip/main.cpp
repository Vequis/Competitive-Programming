#include <iostream>

using namespace std;

void testeP2();

int main() {
  testeP2();
  return 0;
}
